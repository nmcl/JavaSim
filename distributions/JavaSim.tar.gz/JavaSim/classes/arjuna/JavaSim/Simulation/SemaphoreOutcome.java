package arjuna.JavaSim.Simulation;

public class SemaphoreOutcome
{
    static final public int DONE = 0;
    static final public int NOTDONE = 1;
    static final public int WOULD_BLOCK = 2;
};
