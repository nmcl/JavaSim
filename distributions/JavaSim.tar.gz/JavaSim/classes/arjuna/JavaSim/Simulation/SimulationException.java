package arjuna.JavaSim.Simulation;

public class SimulationException extends Exception
{

public SimulationException ()
    {
	super();
    }

public SimulationException (String s)
    {
	super(s);
    }

};
