package arjuna.JavaSim.Simulation;

public class RestartException extends Exception
{

public RestartException ()
    {
	super();
    }

public RestartException (String s)
    {
	super(s);
    }

};
